#Input para el valor del numerador en la fracción
A = int(input("Ingrese el numerador: ")) 
#Input para el valor del denominador en la fracción
B = int(input("Ingrese el denominador: ")) 
#división entre A y B
if A % B == 0: 
    print("El denominador divide exactamente al numerador")
else:
    print("El denominador no divide al numerador de forma exacta")