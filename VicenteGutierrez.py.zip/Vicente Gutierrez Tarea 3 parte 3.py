import datetime

fecha = input("Ingrese una fecha en formato dd-mm-yyyy: ")
dia, mes, anio = map(int, fecha.split("-"))

# Esta sección del código verifica si el año ingresado es bisiesto o no
es_bisiesto = (anio % 4 == 0 and anio % 100 != 0) or (anio % 400 == 0)
if es_bisiesto:
    print(f"El año {anio} es bisiesto")
else:
    print(f"El año {anio} no es bisiesto")
    

# Esta sección del código calcula cuantos días del año han transcurrido
fecha_inicio_anio = datetime.date(anio, 1, 1)
fecha_actual = datetime.date(anio, mes, dia)
dias_transcurridos = (fecha_actual - fecha_inicio_anio).days + 1
print(f"Han transcurrido {dias_transcurridos} días desde el inicio del año")


# Finalmente, esta parte indica el número de días restantes para el natalicio de Sir Isaac Newton (o si ya fué)
natalicio_newton = datetime.date(1642, 12, 25) #fecha del nacimiento de Isaac Newton
dias_faltantes = (natalicio_newton - fecha_actual).days
if dias_faltantes < 0:
    print("El natalicio de Sir Isaac Newton ya pasó este año")
else:
    print(f"Faltan {dias_faltantes} días para el natalicio de Sir Isaac Newton")