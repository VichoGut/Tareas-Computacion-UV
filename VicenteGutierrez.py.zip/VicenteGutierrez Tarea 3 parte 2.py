#Pedir valores delas notas para calcular el promedio
notas = input("Ingrese las notas separadas por espacio: ").split()
#convierte las notas a numeros flotantes para poder utilizarlos como números y no como texto
notas = [float(nota) for nota in notas]
#Calcula el promedio
promedio = sum(notas) / len(notas)
#mensaje según promedio
if promedio >= 4.0:
    print("Felicitaciones, vas camino a aprobar")
elif promedio >= 3.0:
    print("Atencion, vas camino a reprobar")
else:
    print("Pocas posibilidades de aprobar")